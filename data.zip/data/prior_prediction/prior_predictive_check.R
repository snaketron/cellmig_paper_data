require(ggplot2)
require(rstan)
require(patchwork)

get_hdi <- function(vec, hdi_level) {
    sortedPts <- sort(vec)
    ciIdxInc <- floor(hdi_level * length(sortedPts))
    nCIs = length(sortedPts) - ciIdxInc
    ciWidth = rep(0 , nCIs)
    for (i in 1:nCIs) {
        ciWidth[i] = sortedPts[i + ciIdxInc] - sortedPts[i]
    }
    HDImin = sortedPts[which.min(ciWidth)]
    HDImax = sortedPts[which.min(ciWidth) + ciIdxInc]
    HDIlim = c(HDImin, HDImax)
    return(HDIlim)
}

# compile simulation model
S <- stan_model(file = "prior_prediction/S.stan")

# sample
sim <- sampling(object = S,
                algorithm = "Fixed_param",
                chains = 4, 
                iter = 2000, 
                warmup = 1000,
                data = list(N_plate = 6,
                            N_group = 20,
                            N_well_reps = 4,
                            prior_alpha_p_M = 1.7,
                            prior_alpha_p_SD = 1,
                            prior_sigma_bio_M = 0,
                            prior_sigma_bio_SD = 1,
                            prior_sigma_tech_M = 0,
                            prior_sigma_tech_SD = 1,
                            prior_kappa_mu_M = 1.7,
                            prior_kappa_mu_SD = 1,
                            prior_kappa_sigma_M = 0,
                            prior_kappa_sigma_SD = 1,
                            prior_mu_group_M = 0,
                            prior_mu_group_SD = 1,
                            offset = 1))

y <- extract(object = sim, par = "y")$y

# summary of observations
dim(y)
hist(log(y))
max(y)
min(y)
mean(y)
median(y)
exp(1.7)
hist(apply(X = y, MARGIN = 2, FUN = median))
hist(apply(X = y, MARGIN = 2, FUN = mean))


# HDIs of simulations
get_hdi(vec = y, hdi_level = 0.80)
get_hdi(vec = y, hdi_level = 0.90)
get_hdi(vec = y, hdi_level = 0.95)
get_hdi(vec = y, hdi_level = 0.99)

# D
d <- get(load("res/both.RData"))
w <- as.vector(y)
w <- sample(w, size = nrow(d), replace = F)
w <- round(w, digits = 3)

g_D <- ggplot(data = data.frame(v_sim = w, v_obs = d$v))+
    geom_point((aes(x = v_obs, y = v_sim)), size = 0.5)+
    geom_density_2d(aes(x = v_obs, y = v_sim), col = "orange")+
    geom_hline(yintercept = c(min(d$v), max(d$v)), col = "darkgray")+
    scale_x_log10(name = "Observed v")+
    scale_y_log10(name = "Simulated v", limits = c(0.001, 10^6))+
    annotation_logticks(base = 10, sides = "lb")+
    theme_bw(base_size = 10)
g_D


ggsave(file = "prior_prediction/Supplementary_prior_prediction.png", 
       plot = g_D, device = "png", width = 3, height = 3, dpi = 600)

