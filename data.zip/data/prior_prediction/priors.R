library(ggplot2)
library(ggforce)
library(patchwork)
library(reshape2)
library(dplyr)
library(DT)
library(cellmig)


d <- get(load("res/both.RData"))
d$group <- paste0(d$compound, '-', d$dose)
d$dose <- factor(x = d$dose, levels = c("2.5", "5", "10", "40", "low", "high"))


m <- aggregate(v~well+plate+group, data = d, FUN = mean)
colnames(m) <- c("well", "plate", "group", "mu")
v <- aggregate(v~well+plate+group, data = d, FUN = var)
colnames(v) <- c("well", "plate", "group", "var")
D <- merge(x = m, y = v, by = c("well", "plate", "group"))
D$kappa <- D$mu/D$var
D$alpha <- D$mu*D$kappa
D$sd <- sqrt(D$var)
rm(m, v)



g1 <- ggplot(data = D)+
    geom_point(aes(x = mu, y = var), size = 0.7, alpha = 0.5)+
    xlab(label = "Mean")+
    ylab(label = "Variance")+
    theme_bw(base_size = 10)+
    theme(legend.position = "top")+
    scale_x_log10()+
    scale_y_log10()+
    annotation_logticks(base = 10, sides = "lb")

g2 <- ggplot(data = D)+
    geom_histogram(aes(mu/var))+
    xlab(label = "Mean/Variance")+
    ylab(label = "Count")+
    theme_bw(base_size = 10)+
    theme(legend.position = "top")

g3 <- ggplot()+
    geom_density(data = D, aes(log(mu)), col = "steelblue", alpha = 0.5)+
    geom_density(data = d, aes(log(v)), col = "orange", alpha = 0.5)+
    geom_density(data = data.frame(y = rnorm(n=10^5, mean = 1.7, sd = 1)), aes(y), alpha = 0.5)+
    xlab(label = expression("log(v)"))+
    ylab(label = "Density")+
    theme_bw(base_size = 10)+
    theme(legend.position = "none")


g <- (g1|g2|g3)+patchwork::plot_annotation(tag_levels = 'A')


ggsave(file = "prior_prediction/Supplementary_priors.pdf", 
       plot = g, device = "pdf", width = 7, height = 2.3)
