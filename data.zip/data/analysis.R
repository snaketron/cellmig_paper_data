require(reshape2)
require(ggplot2)
require(ggforce)
require(cellmig)

d <- get(load("res/data.RData"))


o <- cellmig(x = d[, c("well", "plate", "compound", "dose", "v", "offset")],
             control = list(mcmc_warmup = 1000,
                            mcmc_steps = 2000,
                            mcmc_chains = 4,
                            mcmc_cores = 4,
                            mcmc_algorithm = "NUTS",
                            adapt_delta = 0.8,
                            max_treedepth = 10))

save(o, file = "res/cellmig.RData", compress = TRUE)
