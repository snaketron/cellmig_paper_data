library(rstan)
library(readxl)
library(reshape2)
library(loo)
library(ggforce)

# Leave one out analysis
d <- get(load("res/both.RData"))
d$dose <- factor(x = d$dose, levels = c("2.5", "5", "10", "40", "low", "high"))
d <- d[d$experiment != "arp",]
d$x <- as.numeric(as.factor(d$well))

model_gamma <- rstan::stan_model(file = "distribution_comparison/model_gamma.stan")
model_lognormal <- rstan::stan_model(file = "distribution_comparison/model_lognormal.stan")
model_exponential <- rstan::stan_model(file = "distribution_comparison/model_exponential.stan")


fit_gamma <- sampling(object = model_gamma, 
                      chains = 3,
                      cores = 3,
                      data = list(N = nrow(d),y = d$v/max(d$v), x = d$x))
fit_lognormal <- sampling(object = model_lognormal, 
                          chains = 3,
                          cores = 3,
                          data = list(N = nrow(d),y = d$v/max(d$v), x = d$x))
fit_exponential <- sampling(object = model_exponential, 
                          chains = 3,
                          cores = 3,
                          data = list(N = nrow(d),y = d$v/max(d$v), x = d$x))

loo(fit_gamma)
loo(fit_lognormal)
loo(fit_exponential)

loo::compare(loo(fit_gamma), loo(fit_lognormal), loo(fit_exponential))

yhat_gamma <- rstan::extract(object = fit_gamma, par = "yhat")$yhat
yhat_gamma <- melt(yhat_gamma)
yhat_gamma$iterations <- NULL
colnames(yhat_gamma) <- c("x", "y")

yhat_lognormal <- rstan::extract(object = fit_lognormal, par = "yhat")$yhat
yhat_lognormal <- melt(yhat_lognormal)
yhat_lognormal$iterations <- NULL
colnames(yhat_lognormal) <- c("x", "y")


# Posterior predictive check
g <- ggplot()+
    facet_wrap(~x, scales = "free")+
    geom_sina(data = d, aes(x = as.factor(x), y = v), size = 0.5)+
    geom_violin(data = yhat_gamma, aes(x = as.factor(x), y = y, col = "Gamma"), 
                fill = NA)+
    geom_violin(data = yhat_lognormal, aes(x = as.factor(x), y = y, col = "LogNormal"), 
                fill = NA)+
    theme_bw()+
    scale_color_manual(name = "model",
                       values = c("Gamma" = "steelblue",
                                  "LogNormal" = "orange"))+
    scale_y_continuous("cell intensity")+
    scale_x_discrete("plates")

ggsave(filename = "g.pdf", plot = g, device = "pdf", width = 8, height = 15)

yhat_gamma <- data.frame(summary(object = fit_gamma, par = "yhat")$summary)
yhat_gamma$group <- "G"
yhat_gamma$x <- 1:6
yhat_lognormal <- data.frame(summary(object = fit_lognormal, par = "yhat")$summary)
yhat_lognormal$group <- "LN"
yhat_lognormal$x <- 1:6
yhat <- rbind(yhat_gamma, yhat_lognormal)


ggplot()+
    geom_sina(data = d, aes(x = as.factor(x), y = y), size = 0.5)+
    geom_point(data = yhat, aes(x = as.factor(x), y = mean, col = group),
               position = position_dodge(width = 0.5))+
    geom_errorbar(data = yhat, aes(x = as.factor(x), y = mean, col = group,
                                   ymin = X2.5., ymax = X97.5.),
               position = position_dodge(width = 0.5))+
    theme_bw()+
    scale_color_manual(values = c("steelblue", "orange"))
